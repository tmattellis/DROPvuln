package ast.statements;

public class BlockCloser extends Statement
{
}
