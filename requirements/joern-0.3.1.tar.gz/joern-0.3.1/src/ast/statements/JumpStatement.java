package ast.statements;

public class JumpStatement extends Statement
{

}
