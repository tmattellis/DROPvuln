package ast.statements;

import ast.expressions.Expression;

public class ForInit extends Expression
{
}
