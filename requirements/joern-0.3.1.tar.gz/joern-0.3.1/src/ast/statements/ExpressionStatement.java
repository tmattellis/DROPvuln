package ast.statements;

public class ExpressionStatement extends ExpressionHolderStatement
{
}
