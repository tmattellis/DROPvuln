package ast.statements;

public class ElseStatement extends BlockStarter
{
}
