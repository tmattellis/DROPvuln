package ast.expressions;

public class ShiftExpression extends BinaryExpression
{
}
