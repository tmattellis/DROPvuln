package ast.expressions;

public class ArrayIndexing extends Expression
{
}
