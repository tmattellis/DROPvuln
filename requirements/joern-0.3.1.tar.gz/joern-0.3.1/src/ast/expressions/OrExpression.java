package ast.expressions;

public class OrExpression extends BinaryExpression
{
}
