package ast.expressions;

public class AdditiveExpression extends BinaryExpression
{
}
