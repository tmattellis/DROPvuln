package ast.expressions;

public class InclusiveOrExpression extends BinaryExpression
{
}
