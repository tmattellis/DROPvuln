package ast.expressions;

// This isn't nice because an operator is
// not a standalone expression and can't
// be evaluated.

public class IncDec extends Expression
{
}
