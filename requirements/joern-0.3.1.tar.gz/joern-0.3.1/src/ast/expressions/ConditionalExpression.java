package ast.expressions;

public class ConditionalExpression extends Expression
{

}
