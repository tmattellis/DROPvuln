package ast.expressions;

import ast.statements.ExpressionHolder;

public class ArgumentList extends ExpressionHolder
{
}
