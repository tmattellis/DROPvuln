package ast.expressions;

public class AndExpression extends BinaryExpression
{
}
