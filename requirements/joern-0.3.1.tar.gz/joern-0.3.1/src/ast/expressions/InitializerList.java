package ast.expressions;

import ast.statements.ExpressionHolder;

public class InitializerList extends ExpressionHolder
{
}
