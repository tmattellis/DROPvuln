package ast.expressions;

public class IncDecOp extends PostfixExpression
{
}
