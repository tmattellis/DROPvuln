package ast.expressions;

public class EqualityExpression extends BinaryExpression
{
}
