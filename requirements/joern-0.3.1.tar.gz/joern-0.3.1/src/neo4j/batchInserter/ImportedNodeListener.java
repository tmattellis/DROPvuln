package neo4j.batchInserter;

public abstract class ImportedNodeListener
{

	abstract public void visitNode(Long funcId);

}
