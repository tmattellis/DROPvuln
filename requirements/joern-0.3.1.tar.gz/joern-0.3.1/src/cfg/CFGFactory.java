package cfg;

import ast.functionDef.FunctionDef;


public class CFGFactory
{
	/* Implement this method for each language */
	public CFG newInstance(FunctionDef functionDefinition)
	{
		return null;
	}		
}
