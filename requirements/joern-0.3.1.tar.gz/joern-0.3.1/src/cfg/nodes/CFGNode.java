package cfg.nodes;

import java.util.Map;

public interface CFGNode
{
	public Map<String, Object> getProperties();
}
