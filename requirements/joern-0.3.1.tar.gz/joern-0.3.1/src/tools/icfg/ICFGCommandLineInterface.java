package tools.icfg;

import tools.UtilCommandLineInterface;

public class ICFGCommandLineInterface extends UtilCommandLineInterface
{

	public void printHelp()
	{
		formater.printHelp("icfg", options);
	}
}
