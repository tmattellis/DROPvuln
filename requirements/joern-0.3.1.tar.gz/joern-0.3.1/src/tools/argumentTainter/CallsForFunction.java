package tools.argumentTainter;

import java.util.LinkedList;
import java.util.List;

public class CallsForFunction
{

	List<Long> blocksCallingSource = new LinkedList<Long>();
	List<String> symbolsUsed = new LinkedList<String>();

	public CallsForFunction()
	{
	}
};
